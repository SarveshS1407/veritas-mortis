"use client";

import React, { useEffect, useRef } from "react";
import { motion } from "framer-motion";

export default function DyingBloodSplatter() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Make canvas full size of its container
    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    // Drip physics configuration
    const drips: {
      x: number;
      y: number;
      speed: number;
      maxLength: number;
      width: number;
      opacity: number;
      currentLength: number;
    }[] = [];

    // Create 12-18 random drip streams originating from under the title
    const dripCount = Math.floor(Math.random() * 7) + 12;
    for (let i = 0; i < dripCount; i++) {
      drips.push({
        x: canvas.width * 0.2 + Math.random() * (canvas.width * 0.6), // Distribute across title width
        y: canvas.height * 0.25 + Math.random() * 20, // Start slightly below title
        speed: 0.5 + Math.random() * 1.5,
        maxLength: 100 + Math.random() * 250,
        width: 1.5 + Math.random() * 3.5,
        opacity: 0.6 + Math.random() * 0.4,
        currentLength: 0,
      });
    }

    let animationFrameId: number;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const drip of drips) {
        if (drip.currentLength < drip.maxLength) {
          drip.currentLength += drip.speed;
        }

        // Draw trail
        ctx.beginPath();
        ctx.moveTo(drip.x, drip.y);
        ctx.lineTo(drip.x, drip.y + drip.currentLength);
        ctx.strokeStyle = `rgba(139, 0, 0, ${drip.opacity})`; // #8B0000
        ctx.lineWidth = drip.width;
        ctx.lineCap = "round";
        ctx.stroke();

        // Draw tear-drop bulb at the end
        const bulbY = drip.y + drip.currentLength;
        const bulbRadius = drip.width * 1.2;
        ctx.beginPath();
        ctx.arc(drip.x, bulbY, bulbRadius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(110, 0, 0, ${drip.opacity + 0.1})`; // Slightly darker bulb
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    // Start rendering
    render();

    return () => {
      window.removeEventListener("resize", resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none flex flex-col items-center pt-[15%] z-20">
      {/* 1. Impact Splatter Mask */}
      <motion.div
        initial={{ scale: 0.2, opacity: 0 }}
        animate={{ scale: [0.2, 1.15, 1], opacity: 1 }}
        transition={{ duration: 0.18, ease: "easeOut" }}
        className="absolute top-[5%] left-1/2 -translate-x-1/2 w-[80%] max-w-[600px] aspect-video z-10"
        style={{
          backgroundImage: "url(/images/blood-title-splatter.png)",
          backgroundSize: "cover",
          backgroundPosition: "center",
          mixBlendMode: "multiply",
          filter: "brightness(0.45) contrast(1.8) drop-shadow(0 4px 8px rgba(0,0,0,0.7))",
        }}
      />

      {/* 2. "VERITAS MORTIS" Title Text */}
      <motion.h1
        initial={{ opacity: 0, filter: "blur(10px)" }}
        animate={{ opacity: 1, filter: "blur(0px)" }}
        transition={{ duration: 0.8, delay: 0.1 }}
        className="font-[family-name:var(--font-nosifer)] text-5xl md:text-7xl text-[#8B0000] z-20 mix-blend-multiply tracking-widest text-center mt-8"
        style={{
          textShadow: "0px 4px 12px rgba(139, 0, 0, 0.4), 0px 2px 4px rgba(0, 0, 0, 0.5)",
        }}
      >
        VERITAS MORTIS
      </motion.h1>

      {/* 3. HTML5 Canvas Fluid Dripping Physics Overlay */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full mix-blend-multiply z-10"
        style={{ filter: "blur(0.5px)" }}
      />
    </div>
  );
}
